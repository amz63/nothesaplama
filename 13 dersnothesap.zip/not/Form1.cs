using System.Drawing;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using System;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace not
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void beta_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Hehe ��te Notun Ve Tahminin Burada!");
            label11.Text = tahmin.Text;
            int sayi1, sayi2;
            int sayi3;
            int sayi4, sayi5, sayi6, sayi7, sayi8, sayi9, sayi10, sayi11, sayi12;
            int sonuc = 0;
            sayi1 = Convert.ToInt32(mat.Text);
            sayi2 = Convert.ToInt32(sos.Text);
            sayi3 = Convert.ToInt32(fen.Text);
            sayi4 = Convert.ToInt32(ing.Text);
            sayi5 = Convert.ToInt32(tr.Text);
            sayi6 = Convert.ToInt32(din.Text);
            sayi7 = Convert.ToInt32(grg.Text);
            sayi8 = Convert.ToInt32(bil.Text);
            sayi9 = Convert.ToInt32(g�r.Text);
            sayi10 = Convert.ToInt32(bed.Text);
            sayi11 = Convert.ToInt32(k�l.Text);
            sayi12 = Convert.ToInt32(m�z.Text);
            sonuc = sayi1 + sayi2;
            sonuc = sonuc + sayi3;
            sonuc = sonuc + sayi4;
            sonuc = sonuc + sayi5;
            sonuc = sonuc + sayi6;
            sonuc = sonuc + sayi7;
            sonuc = sonuc + sayi8;
            sonuc = sonuc + sayi9;
            sonuc = sonuc + sayi10;
            sonuc = sonuc + sayi11;
            sonuc = sonuc + sayi12;
            sonuc = sonuc / 12;
            label12.Text = sonuc.ToString();

            BackgroundImage = pictureBox1.Image;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
