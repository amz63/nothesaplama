﻿namespace not
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            groupBox1 = new GroupBox();
            mat = new TextBox();
            din = new TextBox();
            ing = new TextBox();
            sos = new TextBox();
            fen = new TextBox();
            tr = new TextBox();
            tahmin = new TextBox();
            button1 = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            sss = new GroupBox();
            label12 = new Label();
            label11 = new Label();
            label9 = new Label();
            label8 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            sss.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(mat);
            groupBox1.Controls.Add(din);
            groupBox1.Controls.Add(ing);
            groupBox1.Controls.Add(sos);
            groupBox1.Controls.Add(fen);
            groupBox1.Controls.Add(tr);
            groupBox1.Controls.Add(tahmin);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(52, 47);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(343, 254);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Not Hesaplama Ekranı";
            // 
            // mat
            // 
            mat.Location = new Point(86, 39);
            mat.Name = "mat";
            mat.Size = new Size(84, 23);
            mat.TabIndex = 14;
            // 
            // din
            // 
            din.Location = new Point(86, 145);
            din.Name = "din";
            din.Size = new Size(84, 23);
            din.TabIndex = 13;
            // 
            // ing
            // 
            ing.Location = new Point(86, 177);
            ing.Name = "ing";
            ing.Size = new Size(84, 23);
            ing.TabIndex = 12;
            // 
            // sos
            // 
            sos.Location = new Point(86, 107);
            sos.Name = "sos";
            sos.Size = new Size(84, 23);
            sos.TabIndex = 11;
            // 
            // fen
            // 
            fen.Location = new Point(86, 71);
            fen.Name = "fen";
            fen.Size = new Size(84, 23);
            fen.TabIndex = 10;
            // 
            // tr
            // 
            tr.Location = new Point(86, 211);
            tr.Name = "tr";
            tr.Size = new Size(84, 23);
            tr.TabIndex = 9;
            // 
            // tahmin
            // 
            tahmin.Location = new Point(217, 84);
            tahmin.Name = "tahmin";
            tahmin.Size = new Size(75, 23);
            tahmin.TabIndex = 8;
            // 
            // button1
            // 
            button1.Location = new Point(217, 134);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 7;
            button1.Text = "Hesapla";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(192, 42);
            label7.Name = "label7";
            label7.Size = new Size(131, 15);
            label7.TabIndex = 6;
            label7.Text = "Not Tahminin Yaz / Sayı";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(23, 110);
            label6.Name = "label6";
            label6.Size = new Size(40, 15);
            label6.TabIndex = 5;
            label6.Text = "Sosyal";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(21, 214);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 4;
            label5.Text = "Türkçe";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 180);
            label4.Name = "label4";
            label4.Size = new Size(24, 15);
            label4.TabIndex = 3;
            label4.Text = "İng";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 148);
            label3.Name = "label3";
            label3.Size = new Size(25, 15);
            label3.TabIndex = 2;
            label3.Text = "Din";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 74);
            label2.Name = "label2";
            label2.Size = new Size(26, 15);
            label2.TabIndex = 1;
            label2.Text = "Fen";
            label2.Click += label2_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 42);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 0;
            label1.Text = "Matematik";
            // 
            // pictureBox1
            // 
            pictureBox1.ErrorImage = Properties.Resources.arkaplanhesaplama;
            pictureBox1.Image = Properties.Resources.arkaplanhesaplama;
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(12, 329);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(10, 10);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // sss
            // 
            sss.Controls.Add(label12);
            sss.Controls.Add(label11);
            sss.Controls.Add(label9);
            sss.Controls.Add(label8);
            sss.Location = new Point(472, 66);
            sss.Name = "sss";
            sss.Size = new Size(237, 210);
            sss.TabIndex = 1;
            sss.TabStop = false;
            sss.Text = "Sonuçlar";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(137, 55);
            label12.Name = "label12";
            label12.Size = new Size(19, 15);
            label12.TabIndex = 4;
            label12.Text = "....";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(137, 126);
            label11.Name = "label11";
            label11.Size = new Size(25, 15);
            label11.TabIndex = 3;
            label11.Text = "......";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(22, 126);
            label9.Name = "label9";
            label9.Size = new Size(56, 15);
            label9.TabIndex = 1;
            label9.Text = "Tahminin";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 55);
            label8.Name = "label8";
            label8.Size = new Size(86, 15);
            label8.TabIndex = 0;
            label8.Text = "Not Ortalaman";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(sss);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Form1";
            Text = "Not Hesaplama";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            sss.ResumeLayout(false);
            sss.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label7;
        private Button button1;
        private TextBox mat;
        private TextBox din;
        private TextBox ing;
        private TextBox sos;
        private TextBox fen;
        private TextBox tr;
        private TextBox tahmin;
        private GroupBox sss;
        private Label label12;
        private Label label11;
        private Label label9;
        private Label label8;
    }
}
